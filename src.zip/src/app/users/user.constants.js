const UserRoles = {
  ADMIN: 'ADMIN',
  STANDARD: 'STANDARD',
};

module.exports = { UserRoles };
