const dateScalars = `
  scalar GraphQLDate
  scalar GraphQLTime
  scalar GraphQLDateTime
`;

module.exports = { dateScalars };
